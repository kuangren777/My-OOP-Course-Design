//
// Created by 骆明宇 on 2022/12/2.
//

#ifndef INC_221202C___TEST_H
#define INC_221202C___TEST_H

using namespace std;

bool IsAdmin() {
    return true;
}

#endif //INC_221202C___TEST_H
