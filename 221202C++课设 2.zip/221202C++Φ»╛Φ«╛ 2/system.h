//
// Created by 骆明宇 on 2022/12/19.
//

#ifndef INC_221202C___SYSTEM_H
#define INC_221202C___SYSTEM_H

class PersonSystem {

};

class BookSystem {

};

#endif //INC_221202C___SYSTEM_H
